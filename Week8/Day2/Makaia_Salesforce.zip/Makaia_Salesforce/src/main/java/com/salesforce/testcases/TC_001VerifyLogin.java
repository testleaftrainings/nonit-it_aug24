package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.LoginPage;

public class TC_001VerifyLogin extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		excelFileName="Login";
		testcaseName="Login-salesforce";
		testDescription="Login with valid data";
		authors="Subraja";
		category="smoke";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String uName,String pWord) {
            new LoginPage()
            .enterUsername(uName)
            .enterPassword(pWord)
            .clickLogin()
            .verifyHomePage();
	}

}
