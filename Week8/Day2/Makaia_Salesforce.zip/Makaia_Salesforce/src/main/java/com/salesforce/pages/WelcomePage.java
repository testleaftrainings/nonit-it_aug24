package com.salesforce.pages;

import com.framework.testng.api.base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods{
	
	public WelcomePage verifyHomePage() {
		verifyTitle("Home | Salesforce");
		reportStep("HomePage is verified successfully", "pass");
        return this;
        
	}

}
