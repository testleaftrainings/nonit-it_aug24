package com.salesforce.pages;

import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

	public LoginPage enterUsername(String uName) {
		clearAndType(locateElement("username"), uName);
		reportStep(uName + "is entered successfully", "pass",true);
		return this;
	}
	
	public LoginPage enterPassword(String pWord) {
		clearAndType(locateElement("password"), pWord);
		reportStep(pWord + "is entered successfully", "pass",true);
		return this;
	}
	
	public WelcomePage clickLogin() {
		click(locateElement("Login"));
		reportStep("Login button is clicked successfully", "pass",true);
		return new WelcomePage();
	}

}
