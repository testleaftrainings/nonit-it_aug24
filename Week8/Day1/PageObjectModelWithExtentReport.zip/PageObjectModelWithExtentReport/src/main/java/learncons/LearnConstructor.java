package learncons;

public class LearnConstructor {
	
	int empID;
	String name;
	
	
	//Default Constructor or No Argument
	//Paramaterized constructor
	
	public LearnConstructor() {
		System.out.println("Its from a default constructor");
	}
	
	
	public LearnConstructor(int empID,String name) {
		this();
		System.out.println("Its from a parameterized constructor");
		this.empID=empID;
	// global empID	=21;
		this.name=name;
   // global name=Vineeth;
	}
	
	public static void main(String[] args) {
		//LearnConstructor lc=new LearnConstructor();
		//System.out.println(lc.empID);
		//System.out.println(lc.name);
		LearnConstructor lc1=new LearnConstructor(21, "Vineeth");
		System.out.println(lc1.empID);
		System.out.println(lc1.name);
		
		
	}
	

}
