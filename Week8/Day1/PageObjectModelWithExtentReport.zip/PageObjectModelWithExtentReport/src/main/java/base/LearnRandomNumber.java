package base;

public class LearnRandomNumber {

	public static void main(String[] args) {
	 double random = Math.random();
	 System.out.println(random);

	 int randomNumber=(int) (Math.random()*99999999+999999999);
	 
	 
	 System.out.println("RandomNumber is: "+randomNumber);
	 //0.9893794854710797
	 //0.8483311745887768  *999999999999999+99999999999
	 //1080211623
	 //1067698010
	}

}
