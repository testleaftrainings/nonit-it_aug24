package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {
	
	
	
	@When("Enter the username as {string}")
	public LoginPage enterUsername(String uName) throws IOException {
		getDriver().findElement(By.id("username")).sendKeys(uName);
        reportStep("pass", "username enterted successfully"); 
		return this;
	}
	
	@When("Enter the password as {string}")
	public LoginPage enterPassword(String pWord) throws IOException {
		getDriver().findElement(By.id("password")).sendKeys(pWord);
        reportStep("pass", "password entered successfully");
		return this;
	}
	@When("Click on the login button")
	public WelcomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}

}
