package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;
import pages.WelcomePage;

public class TC001_LoginFunctionality extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setvalues() {
		fileName="Login";

	}
	
	
	@Test(dataProvider = "sendData")
	public void runLogin(String uName, String pWord) {
		LoginPage lp=new LoginPage(driver);
          lp.enterUsername(uName)
          .enterPassword(pWord)
          .clickLogin()
          .verifyLogin();
          
          
          }
	
}
