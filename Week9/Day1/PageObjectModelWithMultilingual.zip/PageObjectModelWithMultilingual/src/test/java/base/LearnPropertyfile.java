package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LearnPropertyfile {

	public static void main(String[] args) throws IOException {
		
		FileInputStream fis=new FileInputStream("src/test/resources/config.en.properties");
		
		Properties prop=new Properties();
		
		prop.load(fis);
		
		String user = prop.getProperty("username");
		
		System.out.println(user);
		
		System.out.println(prop.getProperty("password"));
		
		
		

	}

}
