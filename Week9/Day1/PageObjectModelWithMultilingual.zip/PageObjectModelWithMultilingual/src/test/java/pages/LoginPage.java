package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	
	public LoginPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public LoginPage enterUsername(String uName) {
		String user = prop.getProperty("username");
		driver.findElement(By.id("username")).sendKeys(user);
         return this;
	}
	
	public LoginPage enterPassword(String pWord) {
		driver.findElement(By.id("password")).sendKeys(prop.getProperty("password"));
        return this;
	}
	
	public WelcomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
        return new WelcomePage(driver);
	}

}
