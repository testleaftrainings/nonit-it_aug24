package pages;

import base.BaseClass;

public class ViewLeadPage extends BaseClass {
	
	public void verifyFirstName() {
		System.out.println("Lead is created");

	}

}
