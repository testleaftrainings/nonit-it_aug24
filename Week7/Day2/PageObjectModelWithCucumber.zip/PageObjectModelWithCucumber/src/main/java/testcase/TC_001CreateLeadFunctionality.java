package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001CreateLeadFunctionality extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		fileName="CreateLead";

	}
	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String uName,String pWord, String cName, String fName, String lName) {
		LoginPage lp=new LoginPage();
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.verifyLogin()
		.clickCrmsfa()
		.clickLeadslink()
		.clickCreatelink()
		.enterCompanyname(cName)
		.enterFirstname(fName)
		.enterLastname(lName)
		.clickCreateLeadButton()
		.verifyFirstName();
		
	}

}
